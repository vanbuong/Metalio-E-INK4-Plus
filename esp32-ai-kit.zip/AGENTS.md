# AGENTS.md

Instructions for any AI coding agent (Cursor, Codex, Gemini, …) working in this repository.

1. **Read `CLAUDE.md` first and follow it.** It holds the project facts, the rules, the workflow,
   the commands and the hard rules. Despite its name it applies to every agent and model.
2. **Skills live in `.claude/skills/<name>/SKILL.md`.** Before acting, check whether a skill applies
   (the list is in `.cursor/rules/kit-skills.mdc` and in `CLAUDE.md` → Workflow). If one does, open
   its `SKILL.md` with your file-read tool and follow it. "Invoke the X skill" / `superpowers:X`
   means: read `.claude/skills/X/SKILL.md` and do what it says.
3. Tool names in skills are Claude Code's. Map them as described in
   `.claude/skills/using-superpowers/references/cursor-tools.md`.
4. Codebase questions: if `graphify-out/graph.json` exists, ask the graph first
   (`graphify query "<question>"`), then read only the lines it points to.
