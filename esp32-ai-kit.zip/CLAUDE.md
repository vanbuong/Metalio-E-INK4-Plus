# Agent rules — <PROJECT NAME>

<!-- KIT:PROJECT-FACTS — filled in by the `kit-adopt` skill (or by hand). Keep it short and true. -->
ESP-IDF **<vX.Y>** firmware, target **<esp32 / esp32s3 / ...>** (<Xtensa / RISC-V>), <flash size>,
<PSRAM or none>. Language: <C / C++ / mixed>. Build system: CMake via `idf.py`.
ESP-IDF project directory(ies): `<path>` (`idf.py -C <path> ...`).
Own code: `<folders>`. Vendored / generated (don't edit): `<folders>`.
Hardware: <peripherals, coprocessors, buses>. Features: <what the firmware does>.
<!-- /KIT:PROJECT-FACTS -->

These rules take precedence over any skill. Skills take precedence over default behaviour.

## 0. Understand before changing
- Before planning or changing anything, read `docs/agents/CODEBASE_MAP.md`. If it doesn't exist or
  is stale for the area you're touching, run the `repo-onboarding` skill first.
- Read the code you will change *and its callers* before proposing a design. Name the files.
- If this kit was just copied in and the project section above still has `<placeholders>`, run the
  `kit-adopt` skill first.

## 1. Think before coding
- State assumptions. If a request has more than one reading, list them and ask.
- If a simpler approach exists, say so. If something is unclear (an IDF API, a chip capability,
  a peripheral's behaviour), check headers/datasheets instead of guessing. Name what's confusing.

## 2. Simplicity first
- Minimum code that meets the request; no speculative options, abstractions or configurability.
- Every `esp_err_t` that can fail is checked; no error handling for impossible cases.
- If you wrote 200 lines and it could be 50, rewrite it.

## 3. Surgical changes
- Touch only what the task needs; match the surrounding style (naming, logging, brace style).
- Don't reformat or refactor neighbouring code. Mention dead code you notice; don't delete it.
- Remove only what *your* change made unused. Every changed line traces to the request.

## 4. Goal-driven execution
- Turn each task into a verifiable goal ("write a test that reproduces it, then make it pass").
- Never claim "done/fixed/builds" without fresh output.

## Workflow (skills in `.claude/skills/`)
`superpowers:<name>` in a skill means the project skill `<name>`.

| Stage | Skill |
|---|---|
| Kit just installed / project changed a lot | `kit-adopt` |
| First time in an area / stale map | `repo-onboarding` (graphify if installed + `area-mapper` agent) |
| New feature / design | `brainstorming` → spec in `docs/specs/YYYY-MM-DD-<topic>-design.md` |
| Stress-test a design | `grilling`, `domain-modeling` (`GLOSSARY.md` + `docs/adr/`) |
| Plan | `writing-plans` → `docs/plans/YYYY-MM-DD-<feature>.md` |
| Isolate work | `using-git-worktrees` |
| Build | `executing-plans` (default) or `subagent-driven-development` (only when asked — costly) |
| Code | `test-driven-development` + `firmware-tdd` |
| Bugs | `systematic-debugging` + `esp-firmware-debugging` |
| Done? | `verification-before-completion` + firmware evidence below |
| Review | `requesting-code-review` / `receiving-code-review`, standards in `docs/CODING_STANDARDS.md` |
| Integrate | `finishing-a-development-branch` |

### Firmware evidence (for `verification-before-completion`)
| Claim | Evidence |
|---|---|
| Builds | `idf.py build` exit 0, no new warnings |
| Fits | `idf.py size` — the app still fits its OTA/app partition; note growth > 2 % |
| Logic works | host tests (see `firmware-tdd`) run now, 0 failures |
| Works on device | the user's serial log / screen result — otherwise say "not tested on hardware" |
| Memory | for UI/audio/network changes: free internal heap (+ PSRAM if present) before/after |

## Commands
<!-- KIT:COMMANDS — filled in by `kit-adopt`. Default for Windows + ESP-IDF installed with EIM: -->
A plain PowerShell (including the agent's) does NOT have the IDF environment, so always go through
`tools/idf.ps1`: it picks the newest ESP-IDF matching `tools/idf-version.txt` from
`C:\Espressif\tools\eim_idf.json` (override: `$env:GW_IDF_PATH`), runs `idf.py` with your
arguments in a child process and returns its exit code. Never load an IDF activation script into
your own shell. If `idf.py` is not found, say so; never guess build results.
- Check toolchain: `./tools/idf.ps1 --version`
- Build: `./tools/idf.ps1 -C <project dir> build` — slow the first time; run it in the background.
- Size: `./tools/idf.ps1 -C <project dir> size`
- Host tests: `<command>` (see `firmware-tdd`)
- Flash + monitor (the user runs it, or you with explicit permission for that port):
  `./tools/idf.ps1 -C <project dir> -p COM<n> flash monitor`
- Never run `idf.py set-target` or `fullclean` casually: they wipe `build/` / regenerate `sdkconfig`.
- Hardware steps: you cannot flash or watch the board unless the user lets you use the serial
  port. Give the exact command and what to look for; wait for their log before claiming success.
<!-- /KIT:COMMANDS -->

## Hard rules
- Don't edit `sdkconfig` by hand or commit incidental `sdkconfig` churn; change defaults in
  `sdkconfig.defaults*` or Kconfig and say why.
- Vendored / third-party code and ESP-IDF patches are not modified unless the task is about them;
  say so explicitly when you do.
- Never commit secrets, keys, certificates, tokens, Wi-Fi passwords or device credentials; never log them.
- Target-specific code stays behind `CONFIG_IDF_TARGET_*` / `SOC_*` caps or the board layer.
- Generated/large inputs are not source: regenerate them with their scripts instead of hand-editing.
<!-- KIT:PROJECT-RULES — project-specific hard rules added by `kit-adopt`. -->
<!-- /KIT:PROJECT-RULES -->

## graphify
This project may have a knowledge graph at `graphify-out/` (git-ignored, local to each machine).
- When `graphify-out/graph.json` exists, run `graphify query "<question>"` before your first grep,
  search or source-file read for a codebase question, and put this rule in every subagent prompt that
  explores code. Read raw files only for lines the graph or an earlier read already located. Use
  `graphify path "<A>" "<B>"` for relationships and `graphify explain "<concept>"` for a concept.
- After modifying code, run `graphify update .` (AST only, no API cost).
- Missing or stale graph: rebuild offline with `graphify extract . --code-only` then
  `graphify cluster-only . --no-viz --no-label`. Settings: `.graphifyrc`, `.graphifyignore`.
- Never run graphify without `--code-only` unless the user asks: other modes send files to an LLM API.
