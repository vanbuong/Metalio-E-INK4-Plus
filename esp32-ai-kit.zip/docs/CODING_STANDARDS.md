# Coding standards (for writing and reviewing changes)

The existing code is the first standard: match the file you're in (naming, logging, brace style).
Where the code doesn't decide, use these.

## Structure
- Hardware- or board-specific behaviour goes through the board layer, not `#ifdef`s spread across
  the application.
- Keep logic that doesn't touch hardware in functions without IDF driver calls, so it can be tested
  on a PC (see the `firmware-tdd` skill).
- Prefer extending upstream structures over rewriting them; note upstream-shared files you change.

## C / C++
- Check every fallible `esp_err_t` (`ESP_RETURN_ON_ERROR`, `ESP_GOTO_ON_ERROR`, or explicit handling
  with a log); log failures with `esp_err_to_name`.
- Bounded string handling only (`snprintf`, `strlcpy`, `std::string`); validate lengths of everything
  from the network, files, BLE/Zigbee/UART peers, or NVS.
- Memory: say where big buffers live (PSRAM vs internal/DMA); free on every path; RAII in C++.
- Concurrency: no blocking calls in ISRs or event callbacks; state shared between tasks is protected
  (mutex/queue/atomic); UI libraries only from their own task or under their lock.
- No magic numbers: named constants or Kconfig with a short reason.

## Security
- Never log tokens, keys, passwords or personal data; no secrets in the repo.
- Treat downloaded/received data (OTA images, config files, network frames) as untrusted: check
  sizes, and signatures/checksums where the protocol provides them.

## Review smells (judgement calls)
Mysterious names · duplicated code · long functions (> ~80 lines) · shotgun surgery across many
modules · speculative options · repeated `if (board == X)` switches · copy-pasted driver code.

## Project conventions
<!-- KIT:PROJECT — filled in by `kit-adopt` from the code: naming prefixes, error/log macros in use,
module layout, board-layer rule, anything the team's README or CI enforces. -->
<!-- /KIT:PROJECT -->
