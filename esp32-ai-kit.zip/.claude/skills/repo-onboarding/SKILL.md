---
name: repo-onboarding
description: Build or refresh an understanding of this firmware repo before planning or changing code. Use at the start of work in an unfamiliar area, when docs/agents/CODEBASE_MAP.md is missing or stale, or when the user asks how the project is structured or how something works.
---

# Repo onboarding: map before you change

Goal: a short, accurate, *cited* map in `docs/agents/CODEBASE_MAP.md` that later sessions read
instead of re-exploring. Facts come from files you opened, never from names alone.

## 0. Is a map already there?
Read `docs/agents/CODEBASE_MAP.md`. Check its `Mapped at: <commit>` line against `git log -1`.
- Fresh and covers your area → read it, open the 2–3 files it points to for your task, stop here.
- Stale for your area → refresh only those sections (steps 2–4 for that area).

## 1. Structural graph (fast, offline) — if graphify is installed
`graphify --version` succeeds and `graphify-out/graph.json` is missing or stale →
`graphify extract . --code-only` then `graphify cluster-only . --no-viz --no-label`
(tree-sitter, no LLM, nothing leaves the PC; settings in `.graphifyrc` / `.graphifyignore`).
- Check the graph is about this firmware: `graphify god-nodes`. If vendored libraries dominate the
  top nodes, add their folders to `.graphifyignore` and rebuild.
- Use it for structure: `graphify query "who calls <fn>"`, `graphify path A B`, `graphify explain X`,
  and the communities in `GRAPH_REPORT.md` as a first module split.
- The graph shows *structure*, not intent: confirm every claim you write by opening the code.
Not installed → skip; steps 2–4 work without it (slower).

## 2. Skeleton (you)
Read, in order: README(s); the top-level `CMakeLists.txt` of each ESP-IDF project listed in
`CLAUDE.md`; `main/CMakeLists.txt`; `Kconfig.projbuild` files; the partition table(s);
`sdkconfig.defaults*`; the `app_main` file; the board layer (pin definitions, board init).
Write down: boot sequence, main tasks/threads and their priorities, how drivers/boards are
selected, which Kconfig options switch features, how the app talks to external chips.

## 3. Areas in parallel (area-mapper agents)
Split the own code (from `CLAUDE.md` project facts) into areas — one per component or main
subfolder, plus `tools/`/`scripts/` if relevant. Dispatch one `area-mapper` agent per area
(read-only, parallel; up to 4 at a time), each with: the area path, the skeleton notes from step 2,
the graphify rule from `CLAUDE.md`, and the graph output for that area if any. Each returns a
≤ 300-word report in its fixed format. Spot-check a few citations yourself before using them.
No subagent tool (e.g. in some editors)? Map the areas yourself, one at a time, same format.

## 4. Write the map
`docs/agents/CODEBASE_MAP.md`, at most ~400 lines:
```
# Codebase map            Mapped at: <git short sha> (<date>)
## Build & run            exact commands that worked (or "unverified")
## Boot & runtime         boot sequence, tasks (name, prio, core, stack), event/queue flow
## Modules                one block per area: purpose, entry points (file:function), owns, depends on
## Cross-cutting          logging, settings/NVS keys, Kconfig switches, memory, OTA, security
## Hardware               peripherals → driver file → bus/pins (link the board definition)
## Conventions            naming, error handling, how a new feature is usually added
## Danger zones           timing-sensitive code, ISR/IRAM code, vendored code, shared upstream code
## Open questions         things the code didn't answer
```
Cite `path:line` for every non-obvious claim. Commit the map with the user's OK.

## 5. Before any change
State which map sections and files you read, the call path you will touch, and what could break
(callers, other boards/apps/variants, memory). Then hand off to `brainstorming` / `writing-plans`.
