# Cursor Tool Notes

The skills are written in Claude Code's vocabulary. In Cursor (any model: Claude, Grok, GPT, …)
map them like this. Cursor does not run the kit's Claude Code hooks; the always-applied rules in
`.cursor/rules/kit-*.mdc` replace the session-start hook.

| Skill says | In Cursor |
|---|---|
| "Invoke / use the X skill", `Skill` tool, `superpowers:X` | Open `.claude/skills/X/SKILL.md` with the file-read tool and follow it. Read the extra files it names (prompts, references) the same way. |
| `Agent` / `Task` tool, "dispatch a subagent" | Use Cursor's subagent / background-agent feature if this Cursor version offers it to you. Otherwise do the subagent's job yourself, one at a time, with the same prompt and report format. |
| `TodoWrite`, task list, todos | Cursor's to-do list in the agent panel; if none, a checklist in your reply. |
| `Bash`, `PowerShell` | The terminal tool. On Windows use PowerShell syntax; run long builds in the background. |
| `Read`, `Edit`, `Write`, `Grep`, `Glob` | Cursor's file read/edit/search tools and codebase search. |
| `AskUserQuestion` | Ask in chat: one question, the options, your recommendation first. |
| `ExitPlanMode`, plan mode | Cursor's Plan mode if available; otherwise present the plan and wait for approval. |

## Choosing workflows in Cursor
- Prefer `executing-plans` (inline) over `subagent-driven-development` unless subagents are available.
- `repo-onboarding` step 3 (parallel `area-mapper`s): without subagents, map the areas yourself with
  the format in `.claude/agents/area-mapper.md`.
- Skills that run shell scripts (`.claude/skills/*/scripts/*`) need bash (Git for Windows); call them
  as `bash <path> …` from the terminal.
