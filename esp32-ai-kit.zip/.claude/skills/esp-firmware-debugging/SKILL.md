---
name: esp-firmware-debugging
description: ESP32 / ESP-IDF specifics for debugging this firmware. Use together with systematic-debugging for any crash/panic, boot loop, watchdog, stack overflow, heap or PSRAM exhaustion, peripheral or bus fault, display/audio glitch, Wi-Fi/BLE/Zigbee/MQTT/HTTP problem, OTA failure, or build error.
---

# ESP firmware debugging

Use with `systematic-debugging` (no fix before root cause). This adds ESP-IDF specifics; the
**Project specifics** section at the end holds this repo's own facts (filled in by `kit-adopt`).
Adapted from obra/superpowers `systematic-debugging` and mattpocock/skills `diagnosing-bugs` (MIT).

## 1. Get a feedback loop first
1. Build error → exact `idf.py build` command + the **first** error (not the last).
2. Host test that reproduces it (see `firmware-tdd`).
3. Device: full serial log from boot (`idf.py -p <PORT> monitor`) with the steps taken. You can't
   see the board: ask the user for the whole log, not a snippet. Redact keys/tokens/passwords.
4. Network features: reproduce against the server with a script/curl where possible.

## 2. Read the evidence
- **Panics**: decode backtraces with the monitor, or addr2line for the target's toolchain —
  Xtensa (esp32, esp32s2, esp32s3): `xtensa-<target>-elf-addr2line -pfiaC -e build/<app>.elf <addrs>`;
  RISC-V (esp32c*, esp32h*, esp32p4, …): `riscv32-esp-elf-addr2line -pfiaC -e build/<app>.elf <addrs>`.
  `LoadProhibited`/`StoreProhibited` (Xtensa) or `Load/Store access fault` (RISC-V) = bad pointer;
  `Stack canary` / `Stack protection fault` = task stack; `Interrupt wdt` = blocking in an ISR or with
  interrupts off; `Task wdt` = a task starved others (busy loop, missing `vTaskDelay`, long flash op).
- **Coredump**: if enabled, `idf.py coredump-info` after a crash.
- **Memory**: log `heap_caps_get_free_size(MALLOC_CAP_INTERNAL)` (and `MALLOC_CAP_SPIRAM` if PSRAM)
  plus `heap_caps_get_minimum_free_size` around the failing step. DMA buffers must be internal/DMA-capable.
- **Stacks**: `uxTaskGetStackHighWaterMark(NULL)` in the suspect task before enlarging anything.
- **Buses / peripherals**: check pins against the board definition, pull-ups, bus speed, shared-bus
  locking, and power/reset sequencing of external chips. A chip that "stops answering until a long
  power-off" is often back-powered through its I/O pins while its rail is off.
- **UART / coprocessor links**: baud, framing, flow control, who resets whom, and what happens to
  the link when either side reboots or is reflashed.
- **Network**: TLS error codes are negative hex (map them, don't guess); time not set → TLS date
  failures; reconnect loops → look at the backoff and event-handler order.
- **Config**: what changed last — `git diff` of `sdkconfig*`, Kconfig, partitions, component versions.

## 3. Hypothesise, then test one variable
1–3 falsifiable hypotheses, most likely first, shared with the user. One change at a time.
Temporary logs tagged `[DBG-xxxx]`, at WARN level if the module's log level is lowered, so they
can be found and removed.

## 4. Fix and clean up
Failing test first where the logic is host-testable; one fix at the root cause; re-run the
original loop; `verification-before-completion`; remove every `[DBG-` line.

## 5. Three strikes
Three failed fixes → stop, report what was ruled out, and question the design with the user.

## Project specifics
<!-- KIT:PROJECT — filled in by `kit-adopt`: target + toolchain prefix, ELF path(s), log/monitor
command, decode script if the repo has one, chips/coprocessors and their reset/power paths,
module tags whose log level is lowered, known traps. -->
- Target / toolchain: <…>
- ELF / decode: <…>
- External chips and reset/power: <…>
- Known traps: <…>
<!-- /KIT:PROJECT -->
