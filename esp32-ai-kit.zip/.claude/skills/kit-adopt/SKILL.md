---
name: kit-adopt
description: Adapt this ESP32 AI kit (rules, skills, Cursor rules, graphify, idf.ps1) to the project it was just copied into, or re-tune it after the project changed. Use when CLAUDE.md still has <placeholders>, when the user says "adopt/adapt/set up the kit", or when a skill's project section is wrong or missing.
---

# Adopt the kit to this project

The kit's generic parts work anywhere; its **project sections** must describe *this* repo. You fill
them from facts you verified by reading files — never from folder names or guesses. Ask the user
only for what the repo cannot tell you (e.g. which app is the main one, which ports they flash).

Announce: "Using kit-adopt to tailor the kit to this project." Keep a checklist (one item per step).

## 1. Protect the user's work
- `git status` first. Don't stash, commit, switch branches or touch files the user has modified.
- If the project already has `CLAUDE.md`, `AGENTS.md`, `.cursor/rules/*`, `.claude/settings*.json`
  or `docs/CODING_STANDARDS.md` of its own: **merge**, don't overwrite. Keep their rules (fold
  generic ones into the matching kit section), keep their Cursor rule files, and say what you merged.
- Never write secrets you find (keys, `.pem`, Wi-Fi credentials) into any kit file.

## 2. Scan the project (read, don't guess)
Collect, citing the file each fact comes from:
- **ESP-IDF project directories**: every folder with a top-level `CMakeLists.txt` that includes
  `project.cmake` (may be the repo root, or several under `apps/`, `examples/`, …). Which is main?
- **Target and IDF version**: `CONFIG_IDF_TARGET` and `CONFIG_IDF_INIT_VERSION` in `sdkconfig`,
  `sdkconfig.defaults*`, `dependencies.lock` (`idf:` version), CI files, README.
- **Architecture**: Xtensa (esp32, esp32s2, esp32s3) or RISC-V (esp32c*, esp32h*, esp32p4, esp32s31).
- **Languages**: count `.c`, `.h`, `.cc`, `.cpp`, `.hpp` in own code → C, C++ or mixed.
- **Own code vs vendored**: `EXTRA_COMPONENT_DIRS`, `components/`, `main/`, board folders,
  `managed_components/` (vendored), submodules (`.gitmodules`), third-party folders, generated assets.
  Do NOT assume `components/` is vendored — in many projects it is the project's own code.
- **Board layer**: pin definitions, board variants, Kconfig board choice.
- **External chips / links**: coprocessors (UART/SPI/SDIO), radios, sensors, displays; who resets whom.
- **Tests**: existing host-test framework, folder, run scripts, CI test jobs; does it run on this PC?
- **Build tooling**: how the team builds (scripts, Docker, WSL, CI), patches to ESP-IDF, secure-boot
  / signing variants, flash/merge scripts.
- **Security-sensitive files**: keys, certs, factory data, efuse scripts → hard rules.
- **This PC**: `C:\Espressif\tools\eim_idf.json` (EIM installs) — is a matching IDF installed?

## 3. Fill the project sections
Replace placeholders between `<!-- KIT:… -->` markers; keep the markers so a later re-run can find
them. Be short and true; cite paths.
1. `CLAUDE.md`: title, **KIT:PROJECT-FACTS**, **KIT:COMMANDS** (exact commands incl. `-C <app dir>`
   for multi-app repos and the host-test command), **KIT:PROJECT-RULES** (vendored folders, IDF
   patches, secure-boot/signing files, generated assets, endpoint/config boundaries, multi-app
   "change one app → build the others too" rules, anything the README insists on).
2. `tools/idf-version.txt`: the `major.minor` the project uses (e.g. `5.5`). If not installed on this
   PC, tell the user which EIM version to install. If the team doesn't use EIM/Windows, rewrite the
   Commands section for their setup (WSL, Docker, `export.sh`) instead.
3. `.claude/skills/firmware-tdd/SKILL.md` → **Project test setup**: framework, folder, exact run
   command, how to add a suite. Run the command once if it is cheap and say whether it passed.
4. `.claude/skills/esp-firmware-debugging/SKILL.md` → **Project specifics**: target/toolchain prefix,
   ELF path(s), decode script if present, external chips and their reset/power paths, lowered log tags.
5. `.claude/agents/area-mapper.md`: no project facts needed (it reads `CLAUDE.md`); edit only if the
   project needs a different report shape.
6. `docs/CODING_STANDARDS.md` → **Project conventions**: naming prefixes, error-handling and logging
   macros actually used, module structure, board-layer rule — taken from the code, not invented.
7. `.graphifyrc` and `.graphifyignore`: `language.h=c` for pure-C code, `language.h=cpp` when headers
   declare C++ classes; ignore build outputs, `managed_components/`, vendored trees, generated
   assets, datasheets/images, `.claude/`, `.cursor/`, kit zips.
8. `.gitignore`: add `graphify-out/` and `.superpowers/` (ask before editing a file the user has
   uncommitted changes in).

## 4. Cursor
- Keep `AGENTS.md` and `.cursor/rules/kit-*.mdc` as installed. If the project already had Cursor rules,
  keep them; check none contradicts `CLAUDE.md` and report conflicts to the user.
- If you added or renamed a skill, add it to the list in `.cursor/rules/kit-skills.mdc`.

## 5. graphify (optional, offline)
If `graphify --version` works: `graphify extract . --code-only`, then
`graphify cluster-only . --no-viz --no-label`, then `graphify god-nodes --top 10`. If vendored code
dominates, extend `.graphifyignore` and rebuild. Report nodes / edges / communities. If graphify is
not installed, give the install command from `KIT-README.md` and continue without it.

## 6. Verify and hand over
- `./tools/idf.ps1 --version` prints the expected IDF version (or explain why not).
- Optional and only with the user's OK (it's slow): one build of the main app.
- Grep the kit files for leftover `<…>` placeholders in project sections and for facts from another
  project (e.g. a previous project's name, target, folders).
- Summarise: what you filled, what you merged, what you could not determine (as open questions),
  and the next step: run `repo-onboarding` to write `docs/agents/CODEBASE_MAP.md`.
- Commit nothing unless the user asks.

## Editing skills later
Skills are plain Markdown. To tune one for this project, edit its **project section** (or add one at
the end with `<!-- KIT:PROJECT -->` markers) rather than its generic body, so a newer kit version can
be merged in. Keep each skill's frontmatter `description` accurate: it decides when the skill fires
(Claude Code) and when Cursor's skill index points to it.
