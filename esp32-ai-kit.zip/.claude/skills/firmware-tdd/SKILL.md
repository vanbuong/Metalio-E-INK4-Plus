---
name: firmware-tdd
description: How to apply test-first development in this ESP-IDF firmware. Use with test-driven-development when adding or changing logic (parsers, protocol messages, settings, state machines, coprocessor/bus framing, OTA decisions) or fixing a bug in such logic.
---

# Firmware TDD

Use with `test-driven-development` (the iron law: failing test first). This adds where and how
tests can run for ESP-IDF firmware. The **Project test setup** section at the end is this repo's
(filled in by `kit-adopt`). Adapted from obra/superpowers and mattpocock/skills (MIT).

## Where tests run — find out before the first test
1. Read **Project test setup** below. If it's still a placeholder, look for an existing host-test
   setup (`tests/`, `test/`, `host_test/`, GoogleTest/Unity/CMock/Catch2, a `run_*` script, CI jobs)
   and record the exact command and result there.
2. If it fits the code you're changing, add your test there, in its style.
3. If not, and the logic is pure (no IDF/FreeRTOS/driver calls), propose a **host-test seam** to the
   user before building one: the pure function moves to its own file (header-only works well), and a
   small host build (ESP-IDF `linux` target, plain CMake + Unity/GoogleTest, or a compiler script)
   tests it. Agree on it first — it's new infrastructure in someone else's project.
4. Things only the hardware can show (RF, bus timing, displays, audio, power) get a written device
   check (steps + expected log/screen) instead of fake tests.

## The loop — one behaviour at a time
1. RED: one small test named for the behaviour, with real inputs (a real frame captured from a log,
   a real JSON message with secrets removed).
2. Run it: it must fail for the expected reason.
3. GREEN: simplest code that passes. 4. Whole suite passes; firmware still builds.
5. Refactor only while green.
Bugs: a failing test that reproduces the bug comes first.

## Don't
- Write all tests first, then all code. Assert on internals. Recompute expected values with the
  code under test. Keep code written before its test. Skip RED because "I tested it on the board".

## Project test setup
<!-- KIT:PROJECT — filled in by `kit-adopt`: framework, folder, exact run command(s) on this PC,
how a new suite is registered, mocks/shims available, what is covered, prerequisites. -->
- Framework / folder: <…>
- Run: `<command>` → expected `<pass line>`
- Add a test: <…>
<!-- /KIT:PROJECT -->
